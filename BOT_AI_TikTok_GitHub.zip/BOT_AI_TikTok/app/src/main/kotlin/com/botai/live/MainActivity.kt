package com.botai.live

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.botai.live.ai.ReplyEngine
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                BotAiScreen(
                    onOpenAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )
            }
        }
    }
}

@Composable
private fun BotAiScreen(onOpenAccessibility: () -> Unit) {
    var comment by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }
    var autoDraft by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Siap") }
    val scope = rememberCoroutineScope()
    val engine = remember { ReplyEngine() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("BOT AI", style = MaterialTheme.typography.headlineMedium)
        Text(
            "AI Live Reply Assistant",
            style = MaterialTheme.typography.titleMedium
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AI BALAS KOMENTAR", style = MaterialTheme.typography.titleLarge)
                Text("Masukkan komentar penonton untuk membuat balasan yang sopan dan singkat.")

                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Komentar penonton") },
                    placeholder = { Text("Contoh: kak harga berapa?") }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Mode draft otomatis")
                    Switch(checked = autoDraft, onCheckedChange = { autoDraft = it })
                }

                Button(
                    onClick = {
                        scope.launch {
                            status = "Membuat balasan..."
                            reply = engine.generate(comment)
                            status = "Balasan siap ditinjau"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = comment.isNotBlank()
                ) {
                    Text("BUAT BALASAN AI")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("HASIL AI", style = MaterialTheme.typography.titleLarge)
                Text(if (reply.isBlank()) "Belum ada balasan." else reply)
                if (reply.isNotBlank()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { reply = "" }) {
                            Text("Hapus")
                        }
                        Button(onClick = { status = "Siap dikirim melalui kontrol pengguna" }) {
                            Text("SIAPKAN KIRIM")
                        }
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("FLOATING CONTROLLER", style = MaterialTheme.typography.titleLarge)
                Text("Preset cepat: 1 Harga • 2 Keranjang • 3 Produk")
                Text("Status: $status")
                Button(onClick = onOpenAccessibility, modifier = Modifier.fillMaxWidth()) {
                    Text("AKTIFKAN ACCESSIBILITY")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CONTOH PRESET")
                Text("1 • Harga: \"Untuk harga terbaru, silakan cek produk di keranjang ya kak 🛒\"")
                Text("2 • Keranjang: \"Produk dan detailnya bisa dicek di keranjang ya kak 😊\"")
                Text("3 • Produk: \"Untuk varian dan stok terbaru, silakan cek produk ya kak.\"")
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Catatan: gunakan fitur otomatisasi hanya untuk membantu penggunaan yang sah dan tetap patuhi aturan platform.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
