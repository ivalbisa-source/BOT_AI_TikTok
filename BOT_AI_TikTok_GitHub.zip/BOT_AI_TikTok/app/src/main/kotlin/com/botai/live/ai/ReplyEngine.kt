package com.botai.live.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class ReplyEngine(
    private val endpoint: String = "http://10.0.2.2:8787/reply"
) {
    suspend fun generate(comment: String): String = withContext(Dispatchers.IO) {
        if (comment.isBlank()) return@withContext ""

        // Local fallback keeps the app useful even when the AI server is offline.
        val local = localReply(comment)
        try {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 2500
                readTimeout = 6000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().put("comment", comment).toString()
            connection.outputStream.use { it.write(body.toByteArray()) }

            if (connection.responseCode in 200..299) {
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                JSONObject(text).optString("reply").ifBlank { local }
            } else {
                local
            }
        } catch (_: Exception) {
            local
        }
    }

    private fun localReply(comment: String): String {
        val c = comment.lowercase()
        return when {
            listOf("harga", "berapa", "harganya").any(c::contains) ->
                "Untuk harga terbaru, silakan cek produk di keranjang ya kak 🛒"
            listOf("stok", "ready", "ada gak", "ada?").any(c::contains) ->
                "Untuk stok terbaru, silakan cek pilihan varian pada produk ya kak 😊"
            listOf("cod", "bayar ditempat").any(c::contains) ->
                "Untuk opsi pembayaran, silakan cek pilihan yang tersedia saat checkout ya kak."
            listOf("kirim", "pengiriman", "ongkir").any(c::contains) ->
                "Detail pengiriman dan ongkir bisa dilihat saat checkout ya kak 🚚"
            listOf("makasih", "terima kasih", "thanks").any(c::contains) ->
                "Sama-sama kak 🙏 Terima kasih sudah mampir!"
            else ->
                "Terima kasih sudah bertanya kak 😊 Detailnya bisa dicek pada produk ya."
        }
    }
}
