# BOT AI — TikTok LIVE Reply Assistant

Aplikasi Android pendamping untuk membantu membuat balasan komentar LIVE dengan AI.

## Isi project

- Android app: Jetpack Compose
- AI reply engine: server opsional + fallback lokal
- Accessibility Service: fondasi untuk kontrol/aksesibilitas Android
- Floating controller: fondasi fitur preset cepat
- Server Node.js: proxy AI agar API key tidak ditanam di APK

## Penting

Project ini **tidak menanam API key di aplikasi** dan tidak meminta password/OTP akun TikTok.

Versi pertama memakai alur:
1. komentar dimasukkan/dibaca oleh mekanisme yang sah,
2. AI membuat draft,
3. pengguna meninjau,
4. pengguna memutuskan tindakan berikutnya.

Jangan gunakan otomatisasi untuk spam, manipulasi, atau tindakan yang melanggar aturan platform.

## Persyaratan

- Android Studio versi yang mendukung AGP 9.4
- JDK 17
- Android SDK 37
- Gradle Wrapper 9.6
- Untuk AI server: Node.js 20+ disarankan

Android Gradle Plugin 9.4 membutuhkan Gradle 9.6 dan JDK 17. Compose menggunakan BOM 2026.09.00 pada project ini.

## Cara membuka

1. Extract ZIP.
2. Buka folder `BOT_AI_TikTok` di Android Studio.
3. Tunggu Gradle Sync.
4. Pastikan JDK project = 17.
5. Jalankan `app` pada emulator/perangkat Android.
6. Buka menu Accessibility dari tombol di aplikasi bila ingin mengaktifkan service.

## Mengaktifkan AI server

Masuk ke folder `server`:

```bash
npm install
```

Salin `.env.example` menjadi `.env`, lalu isi:

```env
OPENAI_API_KEY=API_KEY_ANDA
OPENAI_MODEL=gpt-6-luna
PORT=8787
```

Jalankan:

```bash
npm start
```

Tes:

```bash
curl http://localhost:8787/health
```

Untuk Android Emulator, endpoint default aplikasi adalah:

```text
http://10.0.2.2:8787/reply
```

Untuk HP fisik, ubah `ReplyEngine.kt` ke alamat IP komputer/server yang dapat diakses HP pada jaringan yang sama, atau gunakan HTTPS endpoint publik.

## Upload ke GitHub

Buat repository baru bernama `bot-ai`.

Lalu:

```bash
git init
git add .
git commit -m "Initial BOT AI app"
git branch -M main
git remote add origin https://github.com/USERNAME/bot-ai.git
git push -u origin main
```

Jangan pernah commit file `server/.env`.

## Tahap pengembangan berikutnya

1. Database preset balasan.
2. Tombol shortcut 1 / 2 / 3.
3. Floating controller.
4. Mode Approve / Manual / Auto-draft.
5. Riwayat komentar dan balasan.
6. Pengaturan gaya AI.
7. Integrasi hanya dengan mekanisme platform yang tersedia dan diizinkan.
