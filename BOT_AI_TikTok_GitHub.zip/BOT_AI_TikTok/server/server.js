import "dotenv/config";
import express from "express";

const app = express();
app.use(express.json({ limit: "16kb" }));

const port = Number(process.env.PORT || 8787);
const model = process.env.OPENAI_MODEL || "gpt-6-luna";

const SYSTEM_PROMPT = `
Kamu adalah AI pembantu balasan komentar LIVE untuk kreator.
Tugasmu membuat satu balasan singkat dalam bahasa Indonesia.
Gaya: ramah, natural, tidak berlebihan, maksimal 180 karakter.
Jangan mengarang harga, stok, promo, garansi, atau kebijakan yang tidak diberikan.
Jika informasi tidak tersedia, arahkan pengguna untuk mengecek produk/detail resmi.
Jangan membuat komentar massal, provokasi, penipuan, atau spam.
Kembalikan hanya teks balasan.
`;

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "BOT AI reply server" });
});

app.post("/reply", async (req, res) => {
  const comment = typeof req.body?.comment === "string"
    ? req.body.comment.trim()
    : "";

  if (!comment) {
    return res.status(400).json({ error: "comment wajib diisi" });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "OPENAI_API_KEY belum diset" });
  }

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        input: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: comment }
        ]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "AI request gagal"
      });
    }

    const reply = extractOutputText(data);
    if (!reply) {
      return res.status(502).json({ error: "AI tidak mengembalikan teks" });
    }

    res.json({ reply });
  } catch (error) {
    res.status(500).json({ error: "Server AI gagal memproses permintaan" });
  }
});

function extractOutputText(data) {
  if (typeof data?.output_text === "string") return data.output_text.trim();

  const parts = [];
  for (const item of data?.output || []) {
    for (const content of item?.content || []) {
      if (content?.type === "output_text" && typeof content?.text === "string") {
        parts.push(content.text);
      }
    }
  }
  return parts.join("\n").trim();
}

app.listen(port, "0.0.0.0", () => {
  console.log(`BOT AI reply server berjalan di http://localhost:${port}`);
});
